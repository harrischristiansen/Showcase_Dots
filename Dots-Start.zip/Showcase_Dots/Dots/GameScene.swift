//
//  GameScene.swift
//  Dots
//
//  Created by Harris Christiansen on 1/29/16.
//  Copyright (c) 2016 Harris Christiansen. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    
}
